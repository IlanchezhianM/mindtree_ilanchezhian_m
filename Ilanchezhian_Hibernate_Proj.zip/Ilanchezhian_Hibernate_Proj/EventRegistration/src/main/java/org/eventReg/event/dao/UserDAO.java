package org.eventReg.event.dao;

import org.eventReg.event.model.User;

public interface UserDAO {

	User getUserByCredentials(String email, String password);
}
