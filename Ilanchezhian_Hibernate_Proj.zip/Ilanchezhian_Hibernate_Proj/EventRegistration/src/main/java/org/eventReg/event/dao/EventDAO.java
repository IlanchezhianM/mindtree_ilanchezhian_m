package org.eventReg.event.dao;

import java.util.List;

import org.eventReg.event.model.Event;

public interface EventDAO {
	
	public List<Event> getAllEvents();
	
	public Event getEventById(Long eventId);
	
	public Event getEventByTitle(String eventTitle);
	
}
