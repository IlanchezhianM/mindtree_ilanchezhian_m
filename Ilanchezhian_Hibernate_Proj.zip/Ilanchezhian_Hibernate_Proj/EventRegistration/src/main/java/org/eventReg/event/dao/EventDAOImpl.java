package org.eventReg.event.dao;

import java.util.List;

import org.eventReg.event.model.Event;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class EventDAOImpl implements EventDAO {
	
	private SessionFactory sf;
	
	public EventDAOImpl(SessionFactory sf){
		this.sf = sf;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Event> getAllEvents() {
		try {
		List<Event> events = null;
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("from Event");
		query.setCacheable(true);
		events = query.list();
		tx.commit();
		session.close();
		return events;
		} catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}	
	}
	
	@Override
	public Event getEventById(Long eventId) {
	  try{
			Session session = sf.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery("from Event e Where e.eventId=:eventId");
			query.setLong("eventId", eventId);
			Event event = (Event) query.uniqueResult();
			if(event != null){
				System.out.println("event Retrieved from DB::"+event);
			}
			tx.commit();
			session.close();
			return event;
	    } catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}		
	}

	@Override
	public Event getEventByTitle(String eventTitle) {
		try {
			Session session = sf.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery("from Event e Where e.eventTitle=:eventTitle");
			query.setString("eventTitle", eventTitle);
			query.setCacheable(true);
			Event event = (Event) query.uniqueResult();
			if(event != null){
				System.out.println("event Retrieved from DB::"+event);
			}
			tx.commit();
			session.close();
			return event;
		} catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}		
	}

}
