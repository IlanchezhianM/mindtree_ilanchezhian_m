package org.eventReg.event.action;

import javax.servlet.ServletContext;

import org.apache.struts2.util.ServletContextAware;
import org.eventReg.event.dao.UserDAO;
import org.eventReg.event.dao.UserDAOImpl;
import org.eventReg.event.model.User;
import org.hibernate.SessionFactory;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class LoginAction extends ActionSupport implements Action, ModelDriven<User>, ServletContextAware {
	
	@Override
	public String execute() throws Exception {
		try {
		
		SessionFactory sf = (SessionFactory) ctx.getAttribute("SessionFactory");
		UserDAO userDAO = new UserDAOImpl(sf);
		User userDB = userDAO.getUserByCredentials(user.getEmail(), user.getPassword());
		if(userDB == null) {
			addActionError("User Name or Password is wrong");
			return INPUT;
		} else {
			user.setEmail(userDB.getEmail());
			user.setName(userDB.getName());
			return SUCCESS;
		}
		
//		EmployeeDAO employeeDAO = new EmployeeDAOImpl(sf);
//		EventDAO  eventDAO= new EventDAOImpl(sf);
//		Employee emp = new Employee();
//		emp.setMid("M1027723");
//		emp.setName("Ilanchezhian Muthusamy");
//		emp.setEmailId("ilanchezhian.muthusamy@mindtree.com");
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//        String joinDateInString = "2014-09-22";
//        Date joinDate = formatter.parse(joinDateInString);
//        emp.setJoinDate(joinDate);
//        
//        List<Event> events = new ArrayList<Event>();
//        List<Long> eventIds = new ArrayList<Long>();
//        eventIds.add(1L);
//        eventIds.add(2L);
//        employeeDAO.saveEmployee(emp);
//        for(Long eventId : eventIds) {
//        	Event event = eventDAO.getEventById(eventId);
//        	EmployeeEvent employeeEvent = new EmployeeEvent();
//        	employeeEvent.setEmployee(emp);
//        	employeeEvent.setEvent(event);
//        	employeeDAO.saveEmployeeEvent(employeeEvent);
//       }
//        
         
       
	} catch (Exception e) {
		 return ERROR;
	}
	}
	
	
	@Override
	public User getModel() {
		return user;
	}
	
	private User user = new User();
	
	private ServletContext ctx;

	@Override
	public void setServletContext(ServletContext sc) {
		this.ctx = sc;
	}
	
}
