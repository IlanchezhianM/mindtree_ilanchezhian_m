package org.eventReg.event.dao;

import java.util.List;

import org.eventReg.event.model.Employee;
import org.eventReg.event.model.EmployeeEvent;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class EmployeeDAOImpl implements EmployeeDAO {
	
	private SessionFactory sf;
	
	public EmployeeDAOImpl(SessionFactory sf){
		this.sf = sf;
	}

	@Override
	public void saveEmployee(Employee employee) {
		try {
			Session session = sf.openSession();
			Transaction tx = session.beginTransaction();
			session.save(employee);
			tx.commit();
			session.close();
		} catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}
		
	}

	@Override
	public void saveEmployeeEvent(EmployeeEvent employeeEvent) {
		try {
			Session session = sf.openSession();
			Transaction tx = session.beginTransaction();
			session.save(employeeEvent);
			tx.commit();
			session.close();
		} catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}
		
	}

	@Override
	public List<Employee> getAllEmployees() {
		try {
			List<Employee> employees = null;
			Session session = sf.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery("from Employee e order by e.joinDate");
			query.setCacheable(true);
			query.setCacheRegion("eventReg");
			employees = query.list();
			tx.commit();
			session.close();
		    return employees;
		} catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}	
	}

	
//	  Query query = this.entityManager.createNativeQuery("SELECT * FROM EMAIL_LOG WHERE INBOUND_EMAIL_LOG_DETAILS_ID = "
//	    		+ "(SELECT ID FROM INBOUND_EMAIL_LOG_DETAILS WHERE INBOUND_EMAIL_LOG_ID IN "
//	    		+ "(SELECT INBOUND_EMAIL_LOG_ID FROM INBOUND_EMAIL_LOG_DETAILS WHERE ID =:inboundEmailLogDetailsId) ORDER BY CREATED_DATE ASC LIMIT 1 )", EmailLog.class);
//	    query.setParameter("inboundEmailLogDetailsId", inboundEmailLogDetailsId);
//	    emailLog = query.getResultList();
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getEmployeesByEventTitle(String eventTitle) { 
		try {
			List<Employee> employees = null;
			Session session = sf.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery("select ee.employee from  EmployeeEvent ee where ee.event.eventTitle=:eventTitle");
			query.setParameter("eventTitle", eventTitle);
			employees = (List<Employee>)query.list();
			tx.commit();
			session.close();
		    return employees;
		} catch (HibernateException he) {
			throw he;
		} catch (Exception e) {
			throw e;
		}	
	}

}
