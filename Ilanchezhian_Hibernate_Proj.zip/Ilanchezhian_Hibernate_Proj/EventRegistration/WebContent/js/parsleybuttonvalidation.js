    $('#reg-form').data({ listeners: {
        onFormSubmit: function (isFormValid, event) {
            if (!isFormValid) {
                $('#showhidetarget').show();

            }
        }
    } });
     function cleartxtbox(){
             $('input[type=text]').each(function() {
             $(this).val('');
              });
             $('select').each(function() {
             $(this).val('');
            });
            $('input[type=password]').each(function() {
             $(this).val('');
              });
        }
