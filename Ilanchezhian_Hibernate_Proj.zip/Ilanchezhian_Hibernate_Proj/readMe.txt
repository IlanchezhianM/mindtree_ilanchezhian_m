
Please execute the below steps:

1) Execute the DB_SCRIPTS.SQL
2) Change database configuration in hibernate.cfg.xml
3) Import the EventRegistation maven project in Eclipse. 
4) The Project name is "EventRegistration"

Technologies used:

For UI Integration purpose,I have used strurs2

* Struts2
* Hibernate


Login Url: http://localhost:8080/EventRegistration/

Username: chezhian.ila@gmail.com
Password: Welcome123

