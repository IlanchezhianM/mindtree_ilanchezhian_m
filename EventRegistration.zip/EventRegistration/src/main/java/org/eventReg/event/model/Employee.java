package org.eventReg.event.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@Entity
@Table(name="EMPLOYEES")
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE,region="eventReg")
public class Employee implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="MID")
	private String  mid;
		
	@Column(name="NAME")
	private String name;
	
	@Column(name="JOIN_DATE")
	private Date joinDate;
	
	@Column(name="EMAIL_ID")
	private String emailId;
	
	@Transient
	private String selectedEvents;
	
	@Transient
	private String joinDateStr;
	

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSelectedEvents() {
		return selectedEvents;
	}

	public void setSelectedEvents(String selectedEvents) {
		this.selectedEvents = selectedEvents;
	}

	public String getJoinDateStr() {
		  if(null != joinDate){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				joinDateStr =  sdf.format(joinDate);
		  }		
		  return joinDateStr;
	}

	public void setJoinDateStr(String joinDateStr) {
		this.joinDateStr = joinDateStr;
	}

	

   
	

}

