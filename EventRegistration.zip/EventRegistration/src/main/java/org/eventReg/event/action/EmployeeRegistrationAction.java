package org.eventReg.event.action;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;

import org.apache.struts2.util.ServletContextAware;
import org.eventReg.event.dao.EmployeeDAO;
import org.eventReg.event.dao.EmployeeDAOImpl;
import org.eventReg.event.dao.EventDAO;
import org.eventReg.event.dao.EventDAOImpl;
import org.eventReg.event.model.Employee;
import org.eventReg.event.model.EmployeeEvent;
import org.eventReg.event.model.Event;
import org.hibernate.SessionFactory;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;


public class EmployeeRegistrationAction extends ActionSupport implements Action, ModelDriven<Employee>, ServletContextAware {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public List<String> eventList;
	
	public List<Employee> employeeList;
	
	public String successMsg;
	
	public String eventTitle;
	
	
	@Override
	public String execute() throws Exception {
		SessionFactory sf = (SessionFactory) ctx.getAttribute("SessionFactory");
		EmployeeDAO employeeDAO = new EmployeeDAOImpl(sf);
		EventDAO  eventDAO= new EventDAOImpl(sf);
		if(employee != null) {
			if(employee.getSelectedEvents() != null && !employee.getSelectedEvents().isEmpty()) {
				String[] eventTitleArr = employee.getSelectedEvents().split(",");
				for(String eventTitle: eventTitleArr) {
					Event event = eventDAO.getEventByTitle(eventTitle.trim());
		        	EmployeeEvent employeeEvent = new EmployeeEvent();
		        	employeeEvent.setEmployee(employee);
		        	employeeEvent.setEvent(event);
		        	employeeDAO.saveEmployeeEvent(employeeEvent);
				}
				//addActionMessage("Employee Registerd with Events Successfully");
				successMsg = "Employee Registerd with Events Successfully";
		} else {
			employeeDAO.saveEmployee(employee);
			//addActionMessage("Employee Registerd Successfully");
			successMsg = "Employee Registerd Successfully";
		}
			
         return SUCCESS;
		} else {

			return ERROR;
		}
}
		
	
	public String landing() {
		SessionFactory sf = (SessionFactory) ctx.getAttribute("SessionFactory");
		EventDAO  eventDAO= new EventDAOImpl(sf);
		List<Event> events = eventDAO.getAllEvents(); 
		eventList = new ArrayList<String>();
		for(Event event : events) {
			eventList.add(event.getEventTitle());
		}
		 
		return SUCCESS;
	}
	
	public String eventFilterLanding() {
		eventList = loadEvents(); 
		return SUCCESS;
	}
	
	public List<String> loadEvents() {
		SessionFactory sf = (SessionFactory) ctx.getAttribute("SessionFactory");
		EventDAO  eventDAO= new EventDAOImpl(sf);
		List<Event> events = eventDAO.getAllEvents(); 
		eventList = new ArrayList<String>();
		for(Event event : events) {
			eventList.add(event.getEventTitle());
		}
		return eventList;
	}
	
	public String applyEventFilter() {
		if(eventTitle != null) {
		SessionFactory sf = (SessionFactory) ctx.getAttribute("SessionFactory");
		EmployeeDAO employeeDAO = new EmployeeDAOImpl(sf);
		employeeList = employeeDAO.getEmployeesByEventTitle(eventTitle);
		eventList = loadEvents(); 
		return SUCCESS;
		} else {
			return ERROR;
		}
		
	}
	
	
	public String fetchEmployeeList() {
		SessionFactory sf = (SessionFactory) ctx.getAttribute("SessionFactory");
		EmployeeDAO employeeDAO = new EmployeeDAOImpl(sf);
		employeeList = employeeDAO.getAllEmployees();
		return SUCCESS;
	}
	

	@Override
	public Employee getModel() {
		return employee;
	}
	
	private Employee employee = new Employee();
	
	private ServletContext ctx;

	@Override
	public void setServletContext(ServletContext sc) {
		this.ctx = sc;
	}


	public List<String> getEventList() {
		return eventList;
	}


	public void setEventList(List<String> eventList) {
		this.eventList = eventList;
	}


	public String getSuccessMsg() {
		return successMsg;
	}


	public void setSuccessMsg(String successMsg) {
		this.successMsg = successMsg;
	}


	public List<Employee> getEmployeeList() {
		return employeeList;
	}


	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}


	public String getEventTitle() {
		return eventTitle;
	}


	public void setEventTitle(String eventTitle) {
		this.eventTitle = eventTitle;
	}


	

    
	

}
