package org.eventReg.event.dao;

import java.util.List;

import org.eventReg.event.model.Employee;
import org.eventReg.event.model.EmployeeEvent;

public interface EmployeeDAO {

	public void saveEmployee(Employee employee);
	
	public void saveEmployeeEvent(EmployeeEvent employeeEvent);
	
	public List<Employee> getAllEmployees();
	
	public List<Employee> getEmployeesByEventTitle(String eventTitle);
} 
