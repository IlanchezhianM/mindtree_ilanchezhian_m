package com.cms.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.ServletContextAware;
import org.springframework.web.multipart.MultipartFile;

import com.cms.model.Article;
import com.cms.service.ArticleService;

@Controller
public class ArticleController implements ServletContextAware {
	 
	@Autowired
	private ArticleService articleService;
	
	private ServletContext servletContext;
	
	private final int DOWNLOAD_FILE_BUFFER_SIZE = 4096;  
	
	@RequestMapping("*")
	public String hello(HttpServletRequest request) {
	    System.out.println(request.getServletPath());
	    return "redirect:/article/list";
	}
	
	
	@RequestMapping(value = "/article/list", method = RequestMethod.GET)
	public String listArticles(Model model) {
		try {
			Article article = new Article();
			model.addAttribute("article", article);
			
			model.addAttribute("listArticles", articleService.listArticles());
			return "article";
		} catch (Exception e) {
			return "error";
		}
	}
	

	@RequestMapping(value = "/article/add", method = RequestMethod.POST)
	public String addArticleFromForm(@Valid Article article,
	BindingResult bindingResult,
	@RequestParam(value = "image", required = false) MultipartFile image,
	@RequestParam(value = "articleFileContent", required = false) MultipartFile articleFileContent) {
	 
	try {
		 if(article.getId() == null){
			  article.setImage(image.getBytes());
			  article.setImageName(image.getOriginalFilename());
			  article.setArticleFileContent(articleFileContent.getBytes());
			  article.setArticleFileName(articleFileContent.getOriginalFilename()); 
			  article.setCreatedDate(new Timestamp(System.currentTimeMillis()));
			  article.setModifiedDate(new Timestamp(System.currentTimeMillis()));
		  }else{
			  Article existingArticle = articleService.getArticleById(article.getId());
			  if(image == null || image.isEmpty()) {
				  article.setImage(existingArticle.getImage());
				  article.setImageName(existingArticle.getImageName());
			  } else {
				  article.setImage(image.getBytes());
				  article.setImageName(image.getOriginalFilename()); 
			  }
			  if(articleFileContent == null || articleFileContent.isEmpty()) {
				  article.setArticleFileContent(existingArticle.getArticleFileContent());
				  article.setArticleFileName(existingArticle.getArticleFileName());
			  } else {
				  article.setArticleFileContent(articleFileContent.getBytes());
				  article.setArticleFileName(articleFileContent.getOriginalFilename());
			  }
			  article.setCreatedDate(existingArticle.getCreatedDate());
			  article.setModifiedDate(new Timestamp(System.currentTimeMillis()));
		}
	    articleService.saveArticle(article);
	    return "redirect:/article/list";
	} catch (IOException e) {
		bindingResult.reject(e.getMessage());
		return "error";
	} catch (Exception e) {
		bindingResult.reject(e.getMessage());
		return "error";
	} 
	
	
  }
	 
	
	@RequestMapping("/article/remove/{id}")
    public String removeArticle(@PathVariable("id") Long id){
		try {
			articleService.removeArticle(id);
	        return "redirect:/article/list";
		} catch(Exception e) {
			return "error";
		}
    }
 
    @RequestMapping("/article/edit/{id}")
    public String editArticle(@PathVariable("id") Long id, Model model){
    	try {
	        model.addAttribute("article", articleService.getArticleById(id));
	        model.addAttribute("listArticles", articleService.listArticles());
	        return "article";
    	} catch (Exception e) {
    		return "error";
    	}   
        
    }
  
    
    @RequestMapping(value = "/article/downloadArticle/{id}", method = RequestMethod.GET)
   	public @ResponseBody void downloadFiles(@PathVariable("id") Long id,HttpServletRequest request,
   			HttpServletResponse response) {
    	try {
    	Article article = articleService.getArticleById(id);
		if(article != null && article.getArticleFileName() != null) {
    	 String mimeType = this.servletContext.getMimeType(article.getArticleFileName());
         if (mimeType == null) {        
             mimeType = "application/octet-stream";
         }              
         InputStream inputStream = new ByteArrayInputStream(article.getArticleFileContent());
         int fileLength = inputStream.available(); 
         // set content properties and header attributes for the response
         response.setContentType(mimeType);
         response.setContentLength(fileLength);
         String headerKey = "Content-Disposition";
         String headerValue = String.format("attachment; filename=\"%s\"", article.getArticleFileName());
         response.setHeader(headerKey, headerValue);

         // writes the file to the client
         OutputStream outStream = response.getOutputStream();
          
         byte[] buffer = new byte[DOWNLOAD_FILE_BUFFER_SIZE];
         int bytesRead = -1;
          
         while ((bytesRead = inputStream.read(buffer)) != -1) {
             outStream.write(buffer, 0, bytesRead);
         }
          
         inputStream.close();
         outStream.close(); 
		}
    	}catch (Exception e) {
			e.printStackTrace();
	    } 
    }
	

    
    @Override
    public void setServletContext(ServletContext servletContext) {
    	this.servletContext = servletContext;
     
    }
	
}
