package com.cms.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.model.Article;

@Repository("ArticleDAO")
public class ArticleDAOImpl implements ArticleDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(ArticleDAOImpl.class);
    
	@Autowired
	private SessionFactory sessionFactory;


	@Override
	public void saveArticle(Article article) throws Exception {
		try{
			sessionFactory.getCurrentSession().saveOrUpdate(article);
		} catch(HibernateException he) {
			logger.error("HibernateException == " + he);
			throw new Exception("HibernateException in saveArticle()", he);
		}  catch(Exception e) {
			logger.error("Exception == " + e);
			throw new Exception("Exception in saveArticle()", e);
		}
	}		

//	@Override
//	public void updateArticle(Article article) {
////		Session session = sessionFactory.getCurrentSession();
////		session.update(article);
////		logger.info("Article updated successfully, Article Details="+article);
//		try{
//			sessionFactory.getCurrentSession().saveOrUpdate(article);
//		} catch(HibernateException he) {
//			logger.error("Exception == " + he);
//		}  catch(Exception e) {
//			logger.error("Exception == " + e);
//		}
//	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Article> listArticles() throws Exception {
		try{
			Session session = sessionFactory.getCurrentSession();
			List<Article> articleList = session.createQuery("from Article a Order by a.createdDate Desc").list();
			for(Article article : articleList){
				logger.info("Person List::"+article);
			}
			return articleList;
		}  catch(HibernateException he) {
			logger.error("HibernateException in listArticles == "+ he);
			throw new Exception("HibernateException in listArticles()", he);
		} catch(Exception e) {
			logger.error("Exception in listArticles == "+ e);
			throw new Exception("Exception in listArticles()", e);
		}
	}

	@Override
	public Article getArticleById(Long id) throws Exception {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Article a Where a.id=:id");
			query.setParameter("id", id);
			Article article = (Article) query.uniqueResult();
			return article;
		} catch(HibernateException he) {
			logger.error("HibernateException in getArticleById == "+ he);
			throw new Exception("HibernateException in getArticleById()", he);
		} catch(Exception e) {
			logger.error("Exception in getArticleById == "+ e);
			throw new Exception("Exception in getArticleById()", e);
		}
}

	@Override
	public void removeArticle(Long id) throws Exception {
		try {
			Article article =  getArticleById(id);
			if(null != article){
			 sessionFactory.getCurrentSession().delete(article);
			 logger.info("Article deleted successfully, article details="+article);
			} 
	   } catch(HibernateException he) {
			logger.error("HibernateException in removeArticle == "+ he);
			throw new Exception("HibernateException in removeArticle()", he);
		} catch(Exception e) {
			logger.error("Exception in removeArticle == "+ e);
			throw new Exception("Exception in removeArticle()", e);
		}	
	}

}
