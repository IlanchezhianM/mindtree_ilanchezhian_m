package com.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cms.dao.ArticleDAO;
import com.cms.model.Article;

@Service("articleService")
@Transactional(propagation = Propagation.REQUIRED)
public class ArticleServiceImpl implements ArticleService {
	
	@Autowired
	private ArticleDAO articleDAO;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void saveArticle(Article article) throws Exception {
		try{
			this.articleDAO.saveArticle(article);
		} catch(Exception e) {
			throw new Exception("Exception in saveArticle()", e);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<Article> listArticles() throws Exception {
		try {
			return this.articleDAO.listArticles();
		} catch(Exception e) {
			throw new Exception("Exception in listArticles()", e);
		}	
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public Article getArticleById(Long id) throws Exception {
		try {
		  return this.articleDAO.getArticleById(id);
		} catch(Exception e) {
			throw new Exception("Exception in getArticleById() id = "+id, e);
		} 
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void removeArticle(Long id) throws Exception {
		try {
		  this.articleDAO.removeArticle(id);
		} catch(Exception e) {
			throw new Exception("Exception in removeArticle() id = "+id, e);
		} 
	}

}
