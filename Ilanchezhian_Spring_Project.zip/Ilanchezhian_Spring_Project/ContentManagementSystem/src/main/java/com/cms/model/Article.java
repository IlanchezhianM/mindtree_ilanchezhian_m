package com.cms.model;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.codec.binary.Base64;



@Entity
@Table(name="ARTICLE")
public class Article implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7967210233820040678L;

	@Id
	@Column(name="ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="TITLE")
	private String title;
	
	@Column(name="IMAGE")
	private byte[] image;
	
	@Column(name="IMAGE_NAME")
	private String imageName;
	
	@Column(name="ARTICLE_FILE_CONTENT")
	private byte[] articleFileContent;
	
	@Column(name="ARTICLE_FILE_NAME")
	private  String articleFileName;
	
	@Column(name="COMMENTS")
	private String comments;
	
	@Column(name="CREATED_DATE")
	private Timestamp createdDate;
	
	@Column(name="MODIFIED_DATE")
	private Timestamp modifiedDate;
	
	@Transient
	private String imageUrl;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public byte[] getArticleFileContent() {
		return articleFileContent;
	}

	public void setArticleFileContent(byte[] articleFileContent) {
		this.articleFileContent = articleFileContent;
	}

	public String getArticleFileName() {
		return articleFileName;
	}

	public void setArticleFileName(String articleFileName) {
		this.articleFileName = articleFileName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getImageUrl() {
		try {
			if(this.image != null && this.imageName != null) {
				StringBuilder base64EncodedStr = new StringBuilder(); 
				if(this.imageName.contains("jpg")) {
					base64EncodedStr = base64EncodedStr.append("data:image/jpg;base64,"); 
				} else if(this.imageName.contains("jpeg")) {
					base64EncodedStr = base64EncodedStr.append("data:image/jpeg;base64,"); 
				} else if(this.imageName.contains("png")) {
					base64EncodedStr = base64EncodedStr.append("data:image/png;base64,"); 
				}
				byte[] encodeBase64 = Base64.encodeBase64(this.image);
				String base64Encoded = new String(encodeBase64, "UTF-8");
				return this.imageUrl = base64EncodedStr.append(base64Encoded).toString();
			} else {
				return null;
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		}
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Timestamp modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	
	
}
