package com.cms.service;

import java.util.List;

import com.cms.model.Article;

public interface ArticleService {

	public void saveArticle(Article article) throws Exception;
	public List<Article> listArticles() throws Exception;
	public Article getArticleById(Long id) throws Exception;
	public void removeArticle(Long id) throws Exception;
	
}
