
Please execute the below steps:

1) Execute the DB_SCRIPTS.SQL
2) Change database configuration in application-context.xml
3) Import the attached maven project in Eclipse. 
4) The Project name is "ContentManagementSystem"

Technologies used:

* Spring MVC
* Hibernate


Login Url: http://localhost:8080/ContentManagementSystem


